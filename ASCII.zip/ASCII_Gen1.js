var characters ;
var colour = '#00ff00';

// characters = ":;1tf1i,L     ,,,.\'iIIiii...<<..<<..<<..<<..<<";
characters = ":;1tf1i,L     ,,,.\'iI<<<   ..  ...  .. .. >>> .. >> .. >> .. >> Iiii...<<..<<..<<..<<..<<";
// characters = "<.,.,<"


function display(){
    var frames = characters.length;

    var output = document.getElementById("output");

    //"<font color=\"" + colour + "\">" + asd + "</font>"
    for (var i = 0; i< frames; i++){
        output += characters[i];
    }
}

// display();

async function play() {

	var frames = characters.length;
    var lineWidth = 8;
    var lineHeight = 1;

    var c = document.getElementById("output");

    for (var i = 0; i < frames; i++) {

        for(var j = 0; j<lineHeight;j++)
        {
            for(var k = 0; k < lineWidth; k++){
                c.innerHTML += characters[i+k-j*2] != undefined ? characters[i+k-j*2] : characters[Math. floor(Math.random() * characters.length)];
                // document.getElementById("output").innerHTML += characters[Math.min(i+j-k, characters.length-1)] //characters[Math.floor(Math.random() * characters.length)];
            }

            c.innerHTML += "<br/>";
        }


	    await new Promise(r => setTimeout(r, 120));
	}
	play();
}

function setColour(hexString){
	colour = hexString;
}

function pageScroll() {
    window.scrollBy(0,1);
    scrolldelay = setTimeout(pageScroll,10);
}

play();
pageScroll();


